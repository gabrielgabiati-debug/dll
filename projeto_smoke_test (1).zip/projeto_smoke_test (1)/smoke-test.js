(() => {
  const botaoTeste = document.getElementById('run-smoke-test');
  const areaResultados = document.getElementById('smoke-results');

  function executarSmokeTest() {
    const resultados = [];
    const verificar = (nome, condicao, detalhe) => {
      resultados.push({ nome, passou: Boolean(condicao), detalhe: detalhe || '' });
    };

    // Smoke tests: verificações curtas das funções essenciais, não testes exaustivos.
    verificar('SM01 — Página carregada', document.readyState === 'complete' || document.readyState === 'interactive',
      'O documento está disponível no navegador.');
    verificar('SM02 — Título correto', document.title.includes('Loja Express'),
      `Título encontrado: "${document.title}".`);
    verificar('SM03 — Catálogo disponível', document.querySelectorAll('.product-card').length >= 1,
      `${document.querySelectorAll('.product-card').length} produto(s) exibido(s).`);
    verificar('SM04 — Botão de adicionar disponível', document.querySelector('[data-add]') !== null,
      'Existe pelo menos um botão de adicionar ao carrinho.');

    const apiDisponivel = Boolean(window.lojaDemo);
    verificar('SM05 — Funções principais carregadas', apiDisponivel,
      'A interface de carrinho está pronta para uso.');

    if (apiDisponivel) {
      const quantidadeAntes = window.lojaDemo.obterQuantidadeCarrinho();
      const contadorAntes = document.getElementById('cart-count').textContent;
      const mensagemAntes = document.getElementById('app-message').textContent;
      const corAntes = document.getElementById('app-message').style.color;

      window.lojaDemo.limparCarrinho();
      const adicionou = window.lojaDemo.adicionarAoCarrinho(1);
      verificar('SM06 — Adicionar produto ao carrinho', adicionou && window.lojaDemo.obterQuantidadeCarrinho() === 1,
        'Um produto foi adicionado e a quantidade foi atualizada.');

      window.lojaDemo.finalizarCompra();
      verificar('SM07 — Finalizar compra', document.getElementById('app-message').textContent.includes('finalizada com sucesso'),
        'A finalização apresenta uma confirmação.');

      // Restaura o estado para não deixar a página alterada após o teste.
      window.lojaDemo.limparCarrinho();
      if (quantidadeAntes > 0) {
        // O estado anterior era apenas demonstrativo; não recriamos produtos desconhecidos.
      }
      document.getElementById('cart-count').textContent = quantidadeAntes > 0 ? '0' : contadorAntes;
      if (quantidadeAntes > 0) {
        // Carrinho limpo propositalmente para manter um estado previsível após o teste.
      }
      document.getElementById('app-message').textContent = mensagemAntes;
      document.getElementById('app-message').style.color = corAntes;
    }

    const aprovados = resultados.filter(item => item.passou).length;
    const falhas = resultados.length - aprovados;
    areaResultados.replaceChildren();

    resultados.forEach(resultado => {
      const linha = document.createElement('div');
      linha.className = `test-result ${resultado.passou ? 'pass' : 'fail'}`;
      const status = document.createElement('span');
      status.className = 'status';
      status.textContent = resultado.passou ? 'PASSOU' : 'FALHOU';
      const texto = document.createElement('span');
      texto.textContent = resultado.nome + (resultado.detalhe ? ` — ${resultado.detalhe}` : '');
      linha.append(status, texto);
      areaResultados.appendChild(linha);
    });

    const resumo = document.createElement('div');
    resumo.className = `test-summary ${falhas === 0 ? 'pass' : 'fail'}`;
    resumo.textContent = `Resultado: ${aprovados}/${resultados.length} passaram · ${falhas} falha(s).`;
    areaResultados.appendChild(resumo);

    console.group('Smoke Test — Loja Express');
    resultados.forEach(item => item.passou ? console.log('PASSOU:', item.nome, item.detalhe) : console.error('FALHOU:', item.nome, item.detalhe));
    console.log(resumo.textContent);
    console.groupEnd();

    return { total: resultados.length, aprovados, falhas, resultados };
  }

  window.executarSmokeTest = executarSmokeTest;
  botaoTeste.addEventListener('click', executarSmokeTest);
})();
