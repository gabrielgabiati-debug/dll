(() => {
  const produtos = [
    { id: 1, nome: 'Fone sem fio', preco: 129.90 },
    { id: 2, nome: 'Relógio digital', preco: 89.90 },
    { id: 3, nome: 'Caixa de som', preco: 159.90 }
  ];
  const carrinho = new Map();
  const contador = document.getElementById('cart-count');
  const resumo = document.getElementById('cart-summary');
  const mensagem = document.getElementById('app-message');

  function formatarMoeda(valor) {
    return valor.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }

  function atualizarCarrinho() {
    const quantidade = [...carrinho.values()].reduce((total, item) => total + item.quantidade, 0);
    const total = [...carrinho.values()].reduce((soma, item) => soma + item.preco * item.quantidade, 0);
    contador.textContent = String(quantidade);
    resumo.textContent = quantidade === 0
      ? 'Seu carrinho está vazio.'
      : `${quantidade} item(ns) no carrinho · Total: ${formatarMoeda(total)}`;
  }

  function adicionarAoCarrinho(id) {
    const produto = produtos.find(item => item.id === Number(id));
    if (!produto) return false;
    const item = carrinho.get(produto.id) || { ...produto, quantidade: 0 };
    item.quantidade += 1;
    carrinho.set(produto.id, item);
    atualizarCarrinho();
    mensagem.textContent = `${produto.nome} adicionado ao carrinho.`;
    return true;
  }

  document.querySelectorAll('[data-add]').forEach(botao => {
    botao.addEventListener('click', () => adicionarAoCarrinho(botao.dataset.add));
  });

  document.getElementById('checkout-button').addEventListener('click', () => {
    const quantidade = [...carrinho.values()].reduce((total, item) => total + item.quantidade, 0);
    if (quantidade === 0) {
      mensagem.textContent = 'Adicione um produto antes de finalizar a compra.';
      mensagem.style.color = '#b42318';
      return;
    }
    mensagem.style.color = '#087443';
    mensagem.textContent = 'Compra de demonstração finalizada com sucesso!';
    carrinho.clear();
    atualizarCarrinho();
  });

  // API simples para o script de smoke test e para demonstrações no DevTools.
  window.lojaDemo = {
    adicionarAoCarrinho,
    obterQuantidadeCarrinho: () => [...carrinho.values()].reduce((total, item) => total + item.quantidade, 0),
    finalizarCompra: () => document.getElementById('checkout-button').click(),
    obterProdutos: () => produtos.map(produto => ({ ...produto })),
    limparCarrinho: () => { carrinho.clear(); atualizarCarrinho(); mensagem.textContent = ''; mensagem.style.color = '#087443'; }
  };
  atualizarCarrinho();
})();
