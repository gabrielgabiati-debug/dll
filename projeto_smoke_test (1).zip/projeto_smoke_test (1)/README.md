# Loja Express — Projeto de Smoke Test

Projeto didático para demonstrar **teste de fumaça (Smoke Test)** em uma turma de Desenvolvimento de Sistemas.

## O que é Smoke Test?

É um conjunto curto de verificações iniciais que confirma se as partes essenciais de uma aplicação estão funcionando o suficiente para continuar testes mais detalhados. Não substitui os testes funcionais completos.

## Como abrir

1. Extraia o ZIP.
2. Abra a pasta no Visual Studio Code.
3. Abra o arquivo `index.html` no navegador. Pode usar a extensão Live Server do VS Code; também é possível abrir o arquivo diretamente no navegador.
4. Clique em **Executar Smoke Test**.
5. Os resultados aparecem na página e no Console das DevTools (F12 → Console).

Não é necessário instalar Node.js, npm ou Playwright para esta demonstração.

## Executar pelo Console das DevTools

Com a página aberta, pressione F12, escolha Console e digite:

```javascript
executarSmokeTest()
```

A função retorna um objeto com o total, os testes aprovados, as falhas e os detalhes dos resultados.

## Casos de Smoke Test

| ID | Verificação | Resultado esperado |
|---|---|---|
| SM01 | Página carregada | Documento disponível |
| SM02 | Título da página | Contém “Loja Express” |
| SM03 | Catálogo | Pelo menos um produto visível no DOM |
| SM04 | Botão adicionar | Existe botão para adicionar produto |
| SM05 | Funções principais | API do carrinho carregada |
| SM06 | Adicionar produto | Quantidade do carrinho atualizada |
| SM07 | Finalizar compra | Mensagem de confirmação exibida |

## Roteiro para apresentar

1. Explique que Smoke Test verifica rapidamente se as funções críticas estão disponíveis.
2. Mostre a loja e adicione um produto manualmente.
3. Clique em **Executar Smoke Test**.
4. Abra F12 → Console e mostre as mensagens PASSOU/FALHOU.
5. Diferencie smoke test de testes detalhados: o smoke test é amplo e rápido; não testa todas as combinações ou regras de validação.

## Limitações didáticas

- A loja não processa pagamentos e não usa banco de dados.
- Os testes executam no próprio navegador e são voltados a fins didáticos.
- Em projetos reais, smoke tests de maior confiança costumam ser automatizados por uma ferramenta de teste externa e executados após a implantação ou compilação.
