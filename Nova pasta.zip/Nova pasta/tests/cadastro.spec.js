const { test, expect } = require('@playwright/test');

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.evaluate(() => localStorage.clear());
  await page.reload();
});

test('CT01 - cadastrar usuário com dados válidos', async ({ page }) => {
  await page.getByLabel('Nome completo').fill('Ana Souza');
  await page.getByLabel('E-mail').fill('ana@exemplo.com');
  await page.getByLabel('Senha').fill('senha123');
  await page.getByRole('button', { name: 'Cadastrar usuário' }).click();

  await expect(page.getByRole('status')).toHaveText('Usuário cadastrado com sucesso!');
  await expect(page.getByRole('list', { name: 'Lista de usuários' })).toContainText('Ana Souza');
  await expect(page.getByRole('list', { name: 'Lista de usuários' })).toContainText('ana@exemplo.com');
});

test('CT02 - impedir cadastro com campos vazios', async ({ page }) => {
  await page.getByRole('button', { name: 'Cadastrar usuário' }).click();

  await expect(page.locator('#erro-nome')).toHaveText('Informe o nome.');
  await expect(page.locator('#erro-email')).toHaveText('Informe o e-mail.');
  await expect(page.locator('#erro-senha')).toHaveText('Informe a senha.');
  await expect(page.getByRole('list', { name: 'Lista de usuários' })).toContainText('Nenhum usuário cadastrado.');
});

test('CT03 - rejeitar formato de e-mail inválido', async ({ page }) => {
  await page.getByLabel('Nome completo').fill('Ana Souza');
  await page.getByLabel('E-mail').fill('email-invalido');
  await page.getByLabel('Senha').fill('senha123');
  await page.getByRole('button', { name: 'Cadastrar usuário' }).click();

  await expect(page.locator('#erro-email')).toHaveText('Informe um e-mail válido.');
  await expect(page.getByRole('list', { name: 'Lista de usuários' })).toContainText('Nenhum usuário cadastrado.');
});

test('CT04 - rejeitar senha com menos de 6 caracteres', async ({ page }) => {
  await page.getByLabel('Nome completo').fill('Ana Souza');
  await page.getByLabel('E-mail').fill('ana@exemplo.com');
  await page.getByLabel('Senha').fill('123');
  await page.getByRole('button', { name: 'Cadastrar usuário' }).click();

  await expect(page.locator('#erro-senha')).toHaveText('A senha deve ter pelo menos 6 caracteres.');
});

test('CT05 - impedir cadastro de e-mail duplicado, ignorando maiúsculas', async ({ page }) => {
  const cadastrar = async (nome, email) => {
    await page.getByLabel('Nome completo').fill(nome);
    await page.getByLabel('E-mail').fill(email);
    await page.getByLabel('Senha').fill('senha123');
    await page.getByRole('button', { name: 'Cadastrar usuário' }).click();
  };

  await cadastrar('Ana Souza', 'ana@exemplo.com');
  await expect(page.getByRole('status')).toHaveText('Usuário cadastrado com sucesso!');
  await cadastrar('Ana Souza 2', 'ANA@EXEMPLO.COM');

  await expect(page.locator('#erro-email')).toHaveText('Este e-mail já está cadastrado.');
  await expect(page.getByRole('list', { name: 'Lista de usuários' }).locator('li.user')).toHaveCount(1);
});

test('CT06 - limpar a lista de usuários', async ({ page }) => {
  await page.getByLabel('Nome completo').fill('Ana Souza');
  await page.getByLabel('E-mail').fill('ana@exemplo.com');
  await page.getByLabel('Senha').fill('senha123');
  await page.getByRole('button', { name: 'Cadastrar usuário' }).click();

  await page.getByRole('button', { name: 'Limpar lista' }).click();
  await expect(page.getByRole('list', { name: 'Lista de usuários' })).toContainText('Nenhum usuário cadastrado.');
  await expect(page.getByRole('status')).toHaveText('Lista limpa.');
});

test('CT07 - verificar se o elemento lista existe', async ({ page }) => {
  const existe = await page.evaluate(() => {
    return typeof lista !== 'undefined';
  });

  expect(existe).toBe(true);
});