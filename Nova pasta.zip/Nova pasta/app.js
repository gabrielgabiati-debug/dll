const form = document.getElementById('form-cadastro');
const nomeInput = document.getElementById('nome');
const emailInput = document.getElementById('email');
const senhaInput = document.getElementById('senha');
const mensagem = document.getElementById('mensagem');
const lista = document.getElementById('lista-usuarios');
const limparButton = document.getElementById('btn-limpar');

const STORAGE_KEY = 'cadastro-facil-usuarios';

function obterUsuarios() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch {
    return [];
  }
}

function salvarUsuarios(usuarios) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(usuarios));
}

function mostrarErro(campo, texto) {
  document.getElementById(`erro-${campo}`).textContent = texto;
}

function limparErros() {
  ['nome', 'email', 'senha'].forEach(campo => mostrarErro(campo, ''));
  mensagem.textContent = '';
  mensagem.className = 'message';
}

function renderizarUsuarios() {
  const usuarios = obterUsuarios();
  lista.replaceChildren();

  if (usuarios.length === 0) {
    const item = document.createElement('li');
    item.className = 'empty';
    item.textContent = 'Nenhum usuário cadastrado.';
    lista.appendChild(item);
    return;
  }

  usuarios.forEach(usuario => {
    const item = document.createElement('li');
    item.className = 'user';
    const dados = document.createElement('div');
    const nome = document.createElement('strong');
    const email = document.createElement('span');
    nome.textContent = usuario.nome;
    email.textContent = usuario.email;
    dados.append(nome, email);
    item.appendChild(dados);
    lista.appendChild(item);
  });
}

function validar(nome, email, senha) {
  let valido = true;
  if (!nome.trim()) {
    mostrarErro('nome', 'Informe o nome.');
    valido = false;
  }
  if (!email.trim()) {
    mostrarErro('email', 'Informe o e-mail.');
    valido = false;
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    mostrarErro('email', 'Informe um e-mail válido.');
    valido = false;
  }
  if (!senha) {
    mostrarErro('senha', 'Informe a senha.');
    valido = false;
  } else if (senha.length < 6) {
    mostrarErro('senha', 'A senha deve ter pelo menos 6 caracteres.');
    valido = false;
  }
  return valido;
}

form.addEventListener('submit', event => {
  event.preventDefault();
  limparErros();

  const nome = nomeInput.value.trim();
  const email = emailInput.value.trim().toLowerCase();
  const senha = senhaInput.value;

  if (!validar(nome, email, senha)) {
    mensagem.textContent = 'Revise os campos destacados.';
    mensagem.classList.add('error');
    return;
  }

  const usuarios = obterUsuarios();
  if (usuarios.some(usuario => usuario.email === email)) {
    mostrarErro('email', 'Este e-mail já está cadastrado.');
    mensagem.textContent = 'Não foi possível concluir o cadastro.';
    mensagem.classList.add('error');
    return;
  }

  // A senha não é armazenada: este é apenas um protótipo didático no navegador.
  usuarios.push({ nome, email });
  salvarUsuarios(usuarios);
  renderizarUsuarios();
  form.reset();
  mensagem.textContent = 'Usuário cadastrado com sucesso!';
  mensagem.classList.add('success');
});

limparButton.addEventListener('click', () => {
  localStorage.removeItem(STORAGE_KEY);
  renderizarUsuarios();
  limparErros();
  mensagem.textContent = 'Lista limpa.';
  mensagem.classList.add('success');
});

renderizarUsuarios();
