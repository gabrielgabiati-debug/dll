# Cadastro Fácil — demonstração de testes automatizados

Projeto didático para apresentar conceitos básicos de qualidade de software. A aplicação simula um cadastro de usuários no navegador e os testes automatizados usam **Playwright**.

## O que a aplicação faz
- Cadastra nome, e-mail e senha.
- Valida campos obrigatórios.
- Valida o formato básico do e-mail.
- Exige senha com pelo menos 6 caracteres.
- Impede e-mails duplicados, sem diferenciar maiúsculas/minúsculas.
- Lista usuários e permite limpar a lista.

> Aviso: é um protótipo para aula. Não possui servidor nem banco de dados e não deve ser usado em produção. A senha não é salva.

## Requisitos
- Node.js LTS instalado (inclui npm).
- Conexão com a internet na primeira instalação das dependências.

## Como executar
Abra o terminal dentro da pasta do projeto e execute:

```bash
npm install
npx playwright install chromium
npm test
```

O Playwright iniciará o site automaticamente em `http://127.0.0.1:4173`, executará os testes e mostrará o resultado no terminal.

Para abrir o site manualmente, execute `npm run serve` e acesse `http://127.0.0.1:4173`.

## Casos de teste incluídos

| ID | Cenário | Resultado esperado |
|---|---|---|
| CT01 | Cadastro com dados válidos | Mensagem de sucesso e usuário na lista |
| CT02 | Campos vazios | Mensagens de validação e nenhum cadastro |
| CT03 | E-mail inválido | Cadastro bloqueado |
| CT04 | Senha com menos de 6 caracteres | Cadastro bloqueado |
| CT05 | E-mail duplicado, com letras maiúsculas | Segundo cadastro bloqueado |
| CT06 | Limpar lista | Lista volta ao estado vazio |

## Como explicar à turma
- **Teste manual:** uma pessoa executa os passos e verifica o resultado.
- **Teste automatizado:** o Playwright repete os passos e verifica os resultados com `expect`.
- **Caso de teste:** descreve cenário, dados de entrada e resultado esperado.
- **Teste positivo:** CT01 usa dados válidos.
- **Teste negativo:** CT02–CT05 verificam entradas inválidas ou uma regra de negócio.
- **Regressão:** ao alterar o código, execute novamente `npm test` para verificar se funcionalidades existentes continuam funcionando.

## Demonstração sugerida (5–10 minutos)
1. Abra o site e faça um cadastro válido.
2. Tente enviar o formulário vazio.
3. Tente usar um e-mail inválido.
4. Execute `npm test` no terminal e mostre os testes passando.
5. Como demonstração de falha, altere temporariamente uma regra no `app.js`, rode os testes e observe qual cenário falha. Depois reverta a alteração e rode novamente.

## Estrutura
```text
site_teste_automatizado/
├── index.html
├── style.css
├── app.js
├── package.json
├── playwright.config.js
├── README.md
└── tests/
    └── cadastro.spec.js
```
